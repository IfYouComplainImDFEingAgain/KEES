// core/state.js - Application state and configuration
(function() {
    'use strict';

    const SNEED = window.SNEED;

    const defaultEmotes = [
        {
            code: ':lossmanjack:',
            url: 'https://kiwifarms.st/styles/custom/emotes/bmj_loss.png',
            title: 'Loss Man Jack'
        },
        {
            code: ':juice:',
            url: 'https://kiwifarms.st/styles/custom/emotes/bmj_juicy.gif',
            title: 'Juice!'
        },
        {
            code: ':ross:',
            url: 'https://kiwifarms.st/styles/custom/emotes/bmj_ross_hq.png',
            title: 'Ross',
        },
        {
            code: ':gunt:',
            url: 'https://kiwifarms.st/styles/custom/emotes/gunt.gif',
            title: 'Gunt',
        },
        {
            code: '[img]https://files.catbox.moe/0v5vvb.png[/img]',
            text: 'test',
            title: 'Retard Avelloon'
        },
        {
            code: '🤡',
            emoji: '🤡',
            title: 'What are you laughing at?'
        },
        {
            code: '5',
            text: '5',
            title: 'Type a 5 in the chat if you think hes weird.'
        },
        {
            code: '🚨[color=#ff0000]ALERT[/color]🚨 BOSSMAN IS [color=#80ff00]CLIMBING[/color]',
            text: 'Alert Bossman is climbing',
            title: 'Climbing'
        }
    ];

    const toggleButtonConfig = {
        image: 'https://kiwifarms.st/styles/custom/emotes/bmj_ross_hq.png',
        title: 'Toggle emote bar'
    };

    const formatTools = [
        {
            name: 'Bold',
            symbol: 'B',
            wysiwygCommand: 'bold',
            title: 'Bold text'
        },
        {
            name: 'Italic',
            symbol: 'I',
            wysiwygCommand: 'italic',
            title: 'Italic text'
        },
        {
            name: 'Underline',
            symbol: 'U',
            wysiwygCommand: 'underline',
            title: 'Underline text'
        },
        {
            name: 'Strikethrough',
            symbol: 'S',
            wysiwygCommand: 'strikeThrough',
            title: 'Strikethrough text'
        },
        {
            name: 'Center',
            symbol: 'Center',
            customAction: 'centerText',
            title: 'Center text'
        },
        {
            name: 'Size',
            symbol: 'Size',
            customAction: 'sizePicker',
            title: 'Text size'
        },
        {
            name: 'Code',
            symbol: '{ }',
            startTag: '[code]',
            endTag: '[/code]',
            title: 'Code block'
        },
        {
            name: 'URL',
            symbol: '🔗',
            customAction: 'insertUrl',
            title: 'Insert link'
        },
        {
            name: 'Bullet',
            symbol: '•',
            customAction: 'bulletLines',
            title: 'Add bullets to lines'
        },
        {
            name: 'Image',
            symbol: '🖼',
            customAction: 'insertImage',
            title: 'Insert image'
        },
        {
            name: 'Color',
            symbol: '🎨',
            customAction: 'colorPicker',
            title: 'Text color'
        },
        {
            name: 'Rainbow',
            symbol: '🌈',
            customAction: 'rainbowText',
            title: 'Rainbow text'
        },
        {
            name: 'Newline',
            symbol: '↵',
            insertText: '[br]',
            title: 'Insert line break'
        },
        {
            name: 'WysiwygToggle',
            symbol: '<>',
            customAction: 'toggleWysiwyg',
            title: 'Toggle WYSIWYG mode',
            isToggle: true
        },
        {
            name: 'Blacklist',
            symbol: '🚫',
            customAction: 'blacklistManager',
            title: 'Manage blacklisted images'
        },
        {
            name: 'Emotes',
            symbol: '⚙️',
            customAction: 'emoteManager',
            title: 'Manage custom emotes'
        }
    ];

    const CONFIG = {
        MAX_INPUT_HEIGHT: 200,
        RESIZE_DEBOUNCE_DELAY: 16, // ~60fps
        AUTO_SEND_DELAY: 50,
        INIT_DELAY: 500,
        POLLING_CHECK_DELAY: 1000,
        MAX_REINJECT_ATTEMPTS: 10,
        SEND_TIMEOUT: 3000
    };

    const STORAGE_KEYS = {
        EMOTES: 'sneedchat-custom-emotes',
        BLACKLIST: 'sneedchat-image-blacklist',
        WYSIWYG_MODE: 'sneedchat-wysiwyg-mode',
        WATCHED_USERS: 'sneedchat-watched-users',
        DISABLE_HOMEPAGE_CHAT: 'sneedchat-disable-homepage-chat',
        EVERYONE_LIST: 'sneedchat-everyone-list',
        WHISPER_HISTORY: 'kees-whisper-history',
        WHISPER_POSITION: 'kees-whisper-position',
        WHISPER_POSITION_GLOBAL: 'kees-whisper-position-global',
        WHISPER_STATE: 'kees-whisper-state',
        WHISPER_STATE_GLOBAL: 'kees-whisper-state-global',
        WHISPER_RETENTION: 'kees-whisper-retention',
        WHISPER_HIDE_MAIN: 'kees-whisper-hide-main',
        WHISPER_GLOBAL: 'kees-whisper-global',
        WHISPER_LATEST: 'kees-whisper-latest',
        GLOBAL_CHAT: 'kees-global-chat',
        CHAT_WS_URL: 'kees-chat-ws-url',
        CHAT_LAST_ROOM: 'kees-chat-last-room',
        CHAT_USER: 'kees-chat-user',
        BOT_USERS: 'kees-bot-users',
        BOT_COLUMN_ENABLED: 'kees-bot-column-enabled',
        BOT_COLUMN_HIDE_MAIN: 'kees-bot-column-hide-main'
    };

    const runtimeState = {
        emoteBarVisible: false,
        reinjectAttempts: 0,
        emotes: null,
        initialized: false,
        pendingTimers: new Set(),
        wysiwygMode: true,
        disableHomepageChat: false,
        everyoneList: [],
        cachedBlacklist: null
    };

    SNEED.state = SNEED.state || {};
    Object.assign(SNEED.state, {
        defaultEmotes,
        toggleButtonConfig,
        formatTools,
        CONFIG,
        STORAGE_KEYS,
        runtime: runtimeState,

        isEmoteBarVisible() {
            return runtimeState.emoteBarVisible;
        },

        setEmoteBarVisible(visible) {
            runtimeState.emoteBarVisible = visible;
        },

        toggleEmoteBarVisible() {
            runtimeState.emoteBarVisible = !runtimeState.emoteBarVisible;
            return runtimeState.emoteBarVisible;
        },

        getEmotes() {
            return runtimeState.emotes;
        },

        setEmotes(emotes) {
            runtimeState.emotes = emotes;
        },

        incrementReinjectAttempts() {
            return ++runtimeState.reinjectAttempts;
        },

        canReinject() {
            return runtimeState.reinjectAttempts < CONFIG.MAX_REINJECT_ATTEMPTS;
        },

        setInitialized(value) {
            runtimeState.initialized = value;
        },

        isInitialized() {
            return runtimeState.initialized;
        },

        addTimer(id) {
            runtimeState.pendingTimers.add(id);
            return id;
        },

        removeTimer(id) {
            runtimeState.pendingTimers.delete(id);
        },

        clearAllTimers() {
            runtimeState.pendingTimers.forEach(id => clearTimeout(id));
            runtimeState.pendingTimers.clear();
        },

        isWysiwygMode() {
            return runtimeState.wysiwygMode;
        },

        setWysiwygMode(enabled) {
            runtimeState.wysiwygMode = enabled;
        },

        toggleWysiwygMode() {
            runtimeState.wysiwygMode = !runtimeState.wysiwygMode;
            return runtimeState.wysiwygMode;
        },

        isHomepageChatDisabled() {
            return runtimeState.disableHomepageChat;
        },

        setDisableHomepageChat(disabled) {
            runtimeState.disableHomepageChat = disabled;
        },

        toggleDisableHomepageChat() {
            runtimeState.disableHomepageChat = !runtimeState.disableHomepageChat;
            return runtimeState.disableHomepageChat;
        },

        getEveryoneList() {
            return runtimeState.everyoneList;
        },

        setEveryoneList(list) {
            runtimeState.everyoneList = list;
        }
    });

})();
