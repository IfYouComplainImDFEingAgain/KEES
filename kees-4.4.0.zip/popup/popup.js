/**
 * popup.js - Extension popup settings UI
 */
(function() {
    'use strict';

    const STORAGE_KEY_HOMEPAGE_CHAT = 'sneedchat-disable-homepage-chat';
    const STORAGE_KEY_SPONSORED = 'kees-disable-sponsored';
    const STORAGE_KEY_MUTED_USERS = 'sneedchat-muted-users';
    const STORAGE_KEY_REACTION_ENABLED = 'kees-reaction-filter-enabled';
    const STORAGE_KEY_REACTION_MIN = 'kees-reaction-filter-min-reacts';
    const STORAGE_KEY_REACTION_THRESHOLD = 'kees-reaction-filter-bad-threshold';
    const STORAGE_KEY_ZIPLINE_ENABLED = 'kees-zipline-enabled';
    const STORAGE_KEY_ZIPLINE_URL = 'kees-zipline-url';
    const STORAGE_KEY_ZIPLINE_API_KEY = 'kees-zipline-api-key';
    const STORAGE_KEY_ZIPLINE_STRIP_EXIF = 'kees-zipline-strip-exif';
    const STORAGE_KEY_MENTION_NOTIFICATIONS = 'kees-mention-notifications';
    const STORAGE_KEY_MENTION_SHOW_BODY = 'kees-mention-show-body';
    const STORAGE_KEY_SCROLLBACK_LIMIT = 'kees-scrollback-limit';
    const STORAGE_KEY_MUTE_DISRUPTIVE = 'kees-mute-disruptive-guests';
    const STORAGE_KEY_ATTACHMENT_STRIP_EXIF = 'kees-attachment-strip-exif';
    const STORAGE_KEY_EVERYONE_LIST = 'sneedchat-everyone-list';
    const STORAGE_KEY_WHISPER_GLOBAL = 'kees-whisper-global';
    const STORAGE_KEY_WHISPER_HIDE_MAIN = 'kees-whisper-hide-main';
    const STORAGE_KEY_WHISPER_RETENTION = 'kees-whisper-retention';
    const STORAGE_KEY_GLOBAL_CHAT = 'kees-global-chat';
    const STORAGE_KEY_BOSSMAN_LIVE_NOTIFY = 'kees-bossman-live-notify';
    const STORAGE_KEY_BOT_USERS = 'kees-bot-users';
    const STORAGE_KEY_BOT_COLUMN_ENABLED = 'kees-bot-column-enabled';
    const STORAGE_KEY_BOT_COLUMN_HIDE_MAIN = 'kees-bot-column-hide-main';
    const STORAGE_KEY_MUTE_GAMBLING = 'kees-mute-gambling';
    const STORAGE_KEY_SCORCHED_EARTH = 'kees-scorched-earth';

    const disableHomepageChatCheckbox = document.getElementById('disable-homepage-chat');
    const disableSponsoredCheckbox = document.getElementById('disable-sponsored');
    const statusDiv = document.getElementById('status');
    const mutedUsersList = document.getElementById('muted-users-list');
    const mutedUserInput = document.getElementById('muted-user-input');
    const addMutedUserBtn = document.getElementById('add-muted-user-btn');

    // Reaction filter elements
    const reactionFilterEnabled = document.getElementById('reaction-filter-enabled');
    const reactionFilterOptions = document.getElementById('reaction-filter-options');
    const reactionMinReacts = document.getElementById('reaction-min-reacts');
    const reactionBadThreshold = document.getElementById('reaction-bad-threshold');

    // Zipline elements
    const ziplineEnabled = document.getElementById('zipline-enabled');
    const ziplineOptions = document.getElementById('zipline-options');
    const ziplineUrl = document.getElementById('zipline-url');
    const ziplineApiKey = document.getElementById('zipline-api-key');
    const ziplineStripExif = document.getElementById('zipline-strip-exif');

    // Mention notifications elements
    const mentionNotifications = document.getElementById('mention-notifications');
    const mentionShowBody = document.getElementById('mention-show-body');
    const mentionBodySetting = document.getElementById('mention-body-setting');

    // Scrollback elements
    const scrollbackLimit = document.getElementById('scrollback-limit');

    // Disruptive guests element
    const muteDisruptiveGuests = document.getElementById('mute-disruptive-guests');

    // Attachment EXIF element
    const attachmentStripExif = document.getElementById('attachment-strip-exif');

    // ============================================
    // STATUS MESSAGE
    // ============================================

    function showStatus(message) {
        statusDiv.textContent = message;
        statusDiv.classList.add('show');
        setTimeout(() => {
            statusDiv.classList.remove('show');
        }, 1500);
    }

    // ============================================
    // HOMEPAGE CHAT SETTING
    // ============================================

    // Load current settings
    // Whisper elements
    const whisperGlobal = document.getElementById('whisper-global');
    const whisperHideMain = document.getElementById('whisper-hide-main');

    // Gambling mute element
    const muteGambling = document.getElementById('mute-gambling');

    // Scorched earth element
    const scorchedEarth = document.getElementById('scorched-earth');

    // Bossman live alert element
    const bossmanLiveNotify = document.getElementById('bossman-live-notify');

    chrome.storage.local.get([STORAGE_KEY_HOMEPAGE_CHAT, STORAGE_KEY_SPONSORED, STORAGE_KEY_MENTION_NOTIFICATIONS, STORAGE_KEY_MENTION_SHOW_BODY, STORAGE_KEY_MUTE_DISRUPTIVE, STORAGE_KEY_ATTACHMENT_STRIP_EXIF, STORAGE_KEY_WHISPER_GLOBAL, STORAGE_KEY_WHISPER_HIDE_MAIN, STORAGE_KEY_BOSSMAN_LIVE_NOTIFY, STORAGE_KEY_MUTE_GAMBLING, STORAGE_KEY_SCORCHED_EARTH], (result) => {
        disableHomepageChatCheckbox.checked = result[STORAGE_KEY_HOMEPAGE_CHAT] === true;
        disableSponsoredCheckbox.checked = result[STORAGE_KEY_SPONSORED] === true;
        mentionNotifications.checked = result[STORAGE_KEY_MENTION_NOTIFICATIONS] === true;
        mentionShowBody.checked = result[STORAGE_KEY_MENTION_SHOW_BODY] === true;
        mentionBodySetting.style.display = mentionNotifications.checked ? 'flex' : 'none';
        muteDisruptiveGuests.checked = result[STORAGE_KEY_MUTE_DISRUPTIVE] === true;
        // Default to true for privacy
        attachmentStripExif.checked = result[STORAGE_KEY_ATTACHMENT_STRIP_EXIF] !== false;
        whisperGlobal.checked = result[STORAGE_KEY_WHISPER_GLOBAL] === true;
        // Default to true
        whisperHideMain.checked = result[STORAGE_KEY_WHISPER_HIDE_MAIN] !== false;
        bossmanLiveNotify.checked = result[STORAGE_KEY_BOSSMAN_LIVE_NOTIFY] === true;
        muteGambling.checked = result[STORAGE_KEY_MUTE_GAMBLING] === true;
        scorchedEarth.checked = result[STORAGE_KEY_SCORCHED_EARTH] === true;
    });

    // Save homepage chat setting on change
    disableHomepageChatCheckbox.addEventListener('change', () => {
        const disabled = disableHomepageChatCheckbox.checked;

        chrome.storage.local.set({ [STORAGE_KEY_HOMEPAGE_CHAT]: disabled }, () => {
            showStatus('Settings saved!');
        });
    });

    // Save sponsored content setting on change
    disableSponsoredCheckbox.addEventListener('change', () => {
        const disabled = disableSponsoredCheckbox.checked;

        chrome.storage.local.set({ [STORAGE_KEY_SPONSORED]: disabled }, () => {
            showStatus('Settings saved!');
        });
    });

    // Save mute disruptive guests setting on change
    muteDisruptiveGuests.addEventListener('change', () => {
        const enabled = muteDisruptiveGuests.checked;

        chrome.storage.local.set({ [STORAGE_KEY_MUTE_DISRUPTIVE]: enabled }, () => {
            showStatus(enabled ? 'Disruptive guests muted' : 'Disruptive guests unmuted');
        });
    });

    // Save attachment EXIF strip setting on change
    attachmentStripExif.addEventListener('change', () => {
        const enabled = attachmentStripExif.checked;

        chrome.storage.local.set({ [STORAGE_KEY_ATTACHMENT_STRIP_EXIF]: enabled }, () => {
            showStatus(enabled ? 'Attachment EXIF stripping enabled' : 'Attachment EXIF stripping disabled');
        });
    });

    // Save mention notifications setting on change
    mentionNotifications.addEventListener('change', () => {
        const enabled = mentionNotifications.checked;
        mentionBodySetting.style.display = enabled ? 'flex' : 'none';

        chrome.storage.local.set({ [STORAGE_KEY_MENTION_NOTIFICATIONS]: enabled }, () => {
            showStatus(enabled ? 'Mention notifications enabled' : 'Mention notifications disabled');
        });
    });

    // Save mention show body setting on change
    mentionShowBody.addEventListener('change', () => {
        const enabled = mentionShowBody.checked;

        chrome.storage.local.set({ [STORAGE_KEY_MENTION_SHOW_BODY]: enabled }, () => {
            showStatus('Settings saved!');
        });
    });

    // Save mute gambling setting on change
    muteGambling.addEventListener('change', () => {
        const enabled = muteGambling.checked;

        chrome.storage.local.set({ [STORAGE_KEY_MUTE_GAMBLING]: enabled }, () => {
            showStatus(enabled ? 'Gambling messages muted' : 'Gambling messages unmuted');
        });
    });

    // Save scorched earth setting on change
    scorchedEarth.addEventListener('change', () => {
        const enabled = scorchedEarth.checked;

        chrome.storage.local.set({ [STORAGE_KEY_SCORCHED_EARTH]: enabled }, () => {
            showStatus(enabled ? 'Scorched earth enabled' : 'Scorched earth disabled');
        });
    });

    // Save bossman live alert setting on change
    bossmanLiveNotify.addEventListener('change', () => {
        const enabled = bossmanLiveNotify.checked;

        chrome.storage.local.set({ [STORAGE_KEY_BOSSMAN_LIVE_NOTIFY]: enabled }, () => {
            showStatus(enabled ? 'Bossman live alerts enabled' : 'Bossman live alerts disabled');
        });
    });

    // Global chat element
    const globalChat = document.getElementById('global-chat');

    chrome.storage.local.get([STORAGE_KEY_GLOBAL_CHAT], (result) => {
        globalChat.checked = result[STORAGE_KEY_GLOBAL_CHAT] === true;
    });

    globalChat.addEventListener('change', () => {
        const enabled = globalChat.checked;
        chrome.storage.local.set({ [STORAGE_KEY_GLOBAL_CHAT]: enabled }, () => {
            showStatus(enabled ? 'Global chat box enabled' : 'Global chat box disabled');
        });
    });

    // Whisper retention element
    const whisperRetention = document.getElementById('whisper-retention');

    // Load whisper retention
    chrome.storage.local.get([STORAGE_KEY_WHISPER_RETENTION], (result) => {
        whisperRetention.value = result[STORAGE_KEY_WHISPER_RETENTION] ?? 100;
    });

    // Save whisper retention on change
    whisperRetention.addEventListener('change', () => {
        const value = parseInt(whisperRetention.value, 10);
        whisperRetention.value = Math.max(0, Math.min(10000, isNaN(value) ? 100 : value));

        chrome.storage.local.set({ [STORAGE_KEY_WHISPER_RETENTION]: parseInt(whisperRetention.value, 10) }, () => {
            showStatus('Whisper retention saved');
        });
    });

    // Save whisper global setting on change
    whisperGlobal.addEventListener('change', () => {
        const enabled = whisperGlobal.checked;

        chrome.storage.local.set({ [STORAGE_KEY_WHISPER_GLOBAL]: enabled }, () => {
            showStatus(enabled ? 'Global whisper box enabled' : 'Global whisper box disabled');
        });
    });

    // Save whisper hide main setting on change
    whisperHideMain.addEventListener('change', () => {
        const enabled = whisperHideMain.checked;

        chrome.storage.local.set({ [STORAGE_KEY_WHISPER_HIDE_MAIN]: enabled }, () => {
            showStatus(enabled ? 'Whispers hidden from main chat' : 'Whispers shown in main chat');
        });
    });

    // ============================================
    // SCROLLBACK SETTINGS
    // ============================================

    // Load scrollback setting
    chrome.storage.local.get([STORAGE_KEY_SCROLLBACK_LIMIT], (result) => {
        scrollbackLimit.value = result[STORAGE_KEY_SCROLLBACK_LIMIT] ?? 100;
    });

    // Save scrollback limit on change
    scrollbackLimit.addEventListener('change', () => {
        const value = parseInt(scrollbackLimit.value, 10) || 100;
        scrollbackLimit.value = Math.max(50, Math.min(5000, value));

        chrome.storage.local.set({ [STORAGE_KEY_SCROLLBACK_LIMIT]: scrollbackLimit.value }, () => {
            showStatus('Scrollback limit saved');
        });
    });

    // ============================================
    // REACTION FILTER SETTINGS
    // ============================================

    // Load reaction filter settings
    chrome.storage.local.get([
        STORAGE_KEY_REACTION_ENABLED,
        STORAGE_KEY_REACTION_MIN,
        STORAGE_KEY_REACTION_THRESHOLD
    ], (result) => {
        reactionFilterEnabled.checked = result[STORAGE_KEY_REACTION_ENABLED] === true;
        reactionMinReacts.value = result[STORAGE_KEY_REACTION_MIN] ?? 5;
        reactionBadThreshold.value = result[STORAGE_KEY_REACTION_THRESHOLD] ?? 50;

        // Show/hide options based on enabled state
        reactionFilterOptions.style.display = reactionFilterEnabled.checked ? 'flex' : 'none';
    });

    // Toggle reaction filter
    reactionFilterEnabled.addEventListener('change', () => {
        const enabled = reactionFilterEnabled.checked;
        reactionFilterOptions.style.display = enabled ? 'flex' : 'none';

        chrome.storage.local.set({ [STORAGE_KEY_REACTION_ENABLED]: enabled }, () => {
            showStatus(enabled ? 'Reaction filter enabled' : 'Reaction filter disabled');
        });
    });

    // Save min reacts on change
    reactionMinReacts.addEventListener('change', () => {
        const value = parseInt(reactionMinReacts.value, 10) || 5;
        reactionMinReacts.value = Math.max(1, Math.min(100, value));

        chrome.storage.local.set({ [STORAGE_KEY_REACTION_MIN]: reactionMinReacts.value }, () => {
            showStatus('Settings saved!');
        });
    });

    // Save threshold on change
    reactionBadThreshold.addEventListener('change', () => {
        const value = parseInt(reactionBadThreshold.value, 10) || 50;
        reactionBadThreshold.value = Math.max(1, Math.min(100, value));

        chrome.storage.local.set({ [STORAGE_KEY_REACTION_THRESHOLD]: reactionBadThreshold.value }, () => {
            showStatus('Settings saved!');
        });
    });

    // ============================================
    // ZIPLINE SETTINGS
    // ============================================

    // Load Zipline settings
    chrome.storage.local.get([
        STORAGE_KEY_ZIPLINE_ENABLED,
        STORAGE_KEY_ZIPLINE_URL,
        STORAGE_KEY_ZIPLINE_API_KEY,
        STORAGE_KEY_ZIPLINE_STRIP_EXIF
    ], (result) => {
        ziplineEnabled.checked = result[STORAGE_KEY_ZIPLINE_ENABLED] === true;
        ziplineUrl.value = result[STORAGE_KEY_ZIPLINE_URL] || '';
        ziplineApiKey.value = result[STORAGE_KEY_ZIPLINE_API_KEY] || '';
        // Default to true for privacy
        ziplineStripExif.checked = result[STORAGE_KEY_ZIPLINE_STRIP_EXIF] !== false;

        ziplineOptions.style.display = ziplineEnabled.checked ? 'block' : 'none';
    });

    // Toggle Zipline
    ziplineEnabled.addEventListener('change', () => {
        const enabled = ziplineEnabled.checked;
        ziplineOptions.style.display = enabled ? 'block' : 'none';

        chrome.storage.local.set({ [STORAGE_KEY_ZIPLINE_ENABLED]: enabled }, () => {
            showStatus(enabled ? 'Zipline enabled' : 'Zipline disabled');
        });
    });

    // Save Zipline URL
    ziplineUrl.addEventListener('change', () => {
        chrome.storage.local.set({ [STORAGE_KEY_ZIPLINE_URL]: ziplineUrl.value.trim() }, () => {
            showStatus('Zipline URL saved');
        });
    });

    // Save Zipline API key
    ziplineApiKey.addEventListener('change', () => {
        chrome.storage.local.set({ [STORAGE_KEY_ZIPLINE_API_KEY]: ziplineApiKey.value }, () => {
            showStatus('API key saved');
        });
    });

    // Save Zipline strip EXIF setting
    ziplineStripExif.addEventListener('change', () => {
        chrome.storage.local.set({ [STORAGE_KEY_ZIPLINE_STRIP_EXIF]: ziplineStripExif.checked }, () => {
            showStatus(ziplineStripExif.checked ? 'EXIF stripping enabled' : 'EXIF stripping disabled');
        });
    });

    // ============================================
    // BOT COLUMN MANAGEMENT
    // ============================================

    const botColumnEnabled = document.getElementById('bot-column-enabled');
    const botColumnHideMain = document.getElementById('bot-column-hide-main');
    const botUsersList = document.getElementById('bot-users-list');
    const botUserInput = document.getElementById('bot-user-input');
    const addBotUserBtn = document.getElementById('add-bot-user-btn');

    chrome.storage.local.get([STORAGE_KEY_BOT_COLUMN_ENABLED, STORAGE_KEY_BOT_COLUMN_HIDE_MAIN], (result) => {
        botColumnEnabled.checked = result[STORAGE_KEY_BOT_COLUMN_ENABLED] === true;
        botColumnHideMain.checked = result[STORAGE_KEY_BOT_COLUMN_HIDE_MAIN] === true;
    });

    botColumnEnabled.addEventListener('change', () => {
        chrome.storage.local.set({ [STORAGE_KEY_BOT_COLUMN_ENABLED]: botColumnEnabled.checked }, () => {
            showStatus(botColumnEnabled.checked ? 'Bot column enabled' : 'Bot column disabled');
        });
    });

    botColumnHideMain.addEventListener('change', () => {
        chrome.storage.local.set({ [STORAGE_KEY_BOT_COLUMN_HIDE_MAIN]: botColumnHideMain.checked }, () => {
            showStatus(botColumnHideMain.checked ? 'Bots hidden from main chat' : 'Bots shown in main chat');
        });
    });

    function renderBotUsers(users) {
        botUsersList.innerHTML = '';
        users.forEach(username => {
            const item = document.createElement('div');
            item.className = 'muted-user';
            const nameSpan = document.createElement('span');
            nameSpan.className = 'muted-user-name';
            nameSpan.textContent = username;
            const removeBtn = document.createElement('button');
            removeBtn.className = 'muted-user-remove';
            removeBtn.textContent = 'Remove';
            removeBtn.addEventListener('click', () => removeBotUser(username));
            item.appendChild(nameSpan);
            item.appendChild(removeBtn);
            botUsersList.appendChild(item);
        });
    }

    function loadBotUsers() {
        chrome.storage.local.get([STORAGE_KEY_BOT_USERS], (result) => {
            renderBotUsers(result[STORAGE_KEY_BOT_USERS] || []);
        });
    }

    function addBotUser(username) {
        if (!username || !username.trim()) return;
        username = username.trim();
        chrome.storage.local.get([STORAGE_KEY_BOT_USERS], (result) => {
            const users = result[STORAGE_KEY_BOT_USERS] || [];
            if (users.includes(username)) { showStatus('User already in list'); return; }
            users.push(username);
            chrome.storage.local.set({ [STORAGE_KEY_BOT_USERS]: users }, () => {
                renderBotUsers(users);
                botUserInput.value = '';
                showStatus(`Added ${username}`);
            });
        });
    }

    function removeBotUser(username) {
        chrome.storage.local.get([STORAGE_KEY_BOT_USERS], (result) => {
            let users = result[STORAGE_KEY_BOT_USERS] || [];
            users = users.filter(u => u !== username);
            chrome.storage.local.set({ [STORAGE_KEY_BOT_USERS]: users }, () => {
                renderBotUsers(users);
                showStatus(`Removed ${username}`);
            });
        });
    }

    addBotUserBtn.addEventListener('click', () => addBotUser(botUserInput.value));
    botUserInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') addBotUser(botUserInput.value); });
    loadBotUsers();

    // ============================================
    // @EVERYONE LIST MANAGEMENT
    // ============================================

    const everyoneList = document.getElementById('everyone-list');
    const everyoneUserInput = document.getElementById('everyone-user-input');
    const addEveryoneUserBtn = document.getElementById('add-everyone-user-btn');

    function renderEveryoneList(users) {
        everyoneList.innerHTML = '';
        users.forEach(username => {
            const item = document.createElement('div');
            item.className = 'muted-user';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'muted-user-name';
            nameSpan.textContent = username;

            const removeBtn = document.createElement('button');
            removeBtn.className = 'muted-user-remove';
            removeBtn.textContent = 'Remove';
            removeBtn.addEventListener('click', () => removeEveryoneUser(username));

            item.appendChild(nameSpan);
            item.appendChild(removeBtn);
            everyoneList.appendChild(item);
        });
    }

    function loadEveryoneList() {
        chrome.storage.local.get([STORAGE_KEY_EVERYONE_LIST], (result) => {
            const users = result[STORAGE_KEY_EVERYONE_LIST] || [];
            renderEveryoneList(users);
        });
    }

    function addEveryoneUser(username) {
        if (!username || !username.trim()) return;
        username = username.trim();

        chrome.storage.local.get([STORAGE_KEY_EVERYONE_LIST], (result) => {
            const users = result[STORAGE_KEY_EVERYONE_LIST] || [];
            if (users.includes(username)) {
                showStatus('User already in list');
                return;
            }
            users.push(username);
            chrome.storage.local.set({ [STORAGE_KEY_EVERYONE_LIST]: users }, () => {
                renderEveryoneList(users);
                everyoneUserInput.value = '';
                showStatus(`Added ${username}`);
            });
        });
    }

    function removeEveryoneUser(username) {
        chrome.storage.local.get([STORAGE_KEY_EVERYONE_LIST], (result) => {
            let users = result[STORAGE_KEY_EVERYONE_LIST] || [];
            users = users.filter(u => u !== username);
            chrome.storage.local.set({ [STORAGE_KEY_EVERYONE_LIST]: users }, () => {
                renderEveryoneList(users);
                showStatus(`Removed ${username}`);
            });
        });
    }

    addEveryoneUserBtn.addEventListener('click', () => {
        addEveryoneUser(everyoneUserInput.value);
    });

    everyoneUserInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addEveryoneUser(everyoneUserInput.value);
        }
    });

    loadEveryoneList();

    // ============================================
    // MUTED USERS MANAGEMENT
    // ============================================

    function renderMutedUsers(users) {
        mutedUsersList.innerHTML = '';

        users.forEach(username => {
            const item = document.createElement('div');
            item.className = 'muted-user';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'muted-user-name';
            nameSpan.textContent = username;

            const removeBtn = document.createElement('button');
            removeBtn.className = 'muted-user-remove';
            removeBtn.textContent = 'Remove';
            removeBtn.addEventListener('click', () => removeMutedUser(username));

            item.appendChild(nameSpan);
            item.appendChild(removeBtn);
            mutedUsersList.appendChild(item);
        });
    }

    function loadMutedUsers() {
        chrome.storage.local.get([STORAGE_KEY_MUTED_USERS], (result) => {
            const users = result[STORAGE_KEY_MUTED_USERS] || [];
            renderMutedUsers(users);
        });
    }

    function addMutedUser(username) {
        if (!username || !username.trim()) return;

        username = username.trim();

        chrome.storage.local.get([STORAGE_KEY_MUTED_USERS], (result) => {
            const users = result[STORAGE_KEY_MUTED_USERS] || [];

            if (users.includes(username)) {
                showStatus('User already muted');
                return;
            }

            users.push(username);

            chrome.storage.local.set({ [STORAGE_KEY_MUTED_USERS]: users }, () => {
                renderMutedUsers(users);
                mutedUserInput.value = '';
                showStatus(`Muted ${username}`);
            });
        });
    }

    function removeMutedUser(username) {
        chrome.storage.local.get([STORAGE_KEY_MUTED_USERS], (result) => {
            let users = result[STORAGE_KEY_MUTED_USERS] || [];
            users = users.filter(u => u !== username);

            chrome.storage.local.set({ [STORAGE_KEY_MUTED_USERS]: users }, () => {
                renderMutedUsers(users);
                showStatus(`Unmuted ${username}`);
            });
        });
    }

    // Event listeners for adding muted users
    addMutedUserBtn.addEventListener('click', () => {
        addMutedUser(mutedUserInput.value);
    });

    mutedUserInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addMutedUser(mutedUserInput.value);
        }
    });

    // Initial load
    loadMutedUsers();

})();
